## Enckey
It is really a sufferring thing to memorize tons of keys like your bank key or facebook account key and so on,what's more, most of them need to be updated periodically. However it is not a smart act to just write your keys down on your notebook or smartphone which most people do. In fact, there is no any secure place that you can hide your keys from being spied. So enckey is a python package to solve this anti-human problem. Enckey is based on the commonly used cryptography algorithm AES, it can encrypt the whole keys mentioned above with merely one 128-bit AES key and store them on your disk as cipher. Now you can  feel free to write even hundreds of your keys as cipher on your laptop or smartphone without worrying about the safety, but you only have to remember one single key.

## Install
* Source code
clone this project, cd to the root directory of enckey, run `install.sh` script to install

## Usage
``` python
from enckey.enckey import Enckey

client = Enckey()

# client.set_key('88888888') # specify your key, longer than 6 bytes but shorter than 16 bytes
# client.set_keys_file('home/keys.file') # specify your cipher file location, default is '${HOME}/keys.file'

client.encrypt('my_bank_key', 'my_key_description')



```